

var arr = [];

arr[0] = 1;
arr[1] = 2;
arr["cat"] = 'meow';

console.log(arr.length);
console.log(arr);

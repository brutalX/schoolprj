
setTimeout(() => {
    console.log("I've done my work!");
}, 2000);


console.log("I'm waiting for all my work to finish.");

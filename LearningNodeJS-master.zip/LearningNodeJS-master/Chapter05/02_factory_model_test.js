var fmm = require('./02_factory_model_module.js');

var abc = fmm.create_ABC();

abc.functionA(4, 5);

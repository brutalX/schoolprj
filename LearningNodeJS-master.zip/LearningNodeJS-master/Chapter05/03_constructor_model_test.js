var abc = require('./03_constructor_model_module.js');
var obj = new abc();
obj.functionA(1, 2);



// simulate a request coming in every 5s
setInterval(function () {
    console.log("got request");
}, 2000);


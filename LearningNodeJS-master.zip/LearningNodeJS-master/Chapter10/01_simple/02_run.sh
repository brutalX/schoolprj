#!/bin/bash

while true
do
    node 02_occasional_crash.js
done

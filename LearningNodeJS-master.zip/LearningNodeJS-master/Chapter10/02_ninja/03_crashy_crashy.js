
setTimeout(function () {
    throw new Error("Crashy Crashy McCrasherson");
}, 2000);



setInterval(function() { console.log("hello"); }, 1000);



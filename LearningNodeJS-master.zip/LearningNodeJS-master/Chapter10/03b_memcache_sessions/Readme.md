
# Running this Sample


To run this sample, you need memcached installed.



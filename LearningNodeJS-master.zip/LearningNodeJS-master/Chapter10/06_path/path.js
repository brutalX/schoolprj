var path = require('path');

var comps = [ '..', 'static', 'photos' ];
console.log(comps.join(path.sep));

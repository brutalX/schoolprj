#!/usr/local/bin/node

console.log("process environment:");
console.log(process.env);

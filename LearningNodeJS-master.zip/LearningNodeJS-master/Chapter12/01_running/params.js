#!/usr/local/bin/node

console.log(process.argv);

#!/usr/local/bin/node

console.log("Very sweet -- you can run node as a #!'d executable on Unix");
console.log("You ran me with the following parameters:");
console.log(process.argv);


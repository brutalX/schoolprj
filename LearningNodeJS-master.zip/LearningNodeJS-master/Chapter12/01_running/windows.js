
console.log(process.argv);



console.log("Starting Server woo!");

setTimeout(function () {
    console.error("OH noes, I'm dying!");
}, 5000);



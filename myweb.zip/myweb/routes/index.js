var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  let articles = [
    {
      id:1,
      title:'Article One',
      author:'Andy G',
      body:'This is article one'
    },
    {
      id:2,
      title:'Article Two',
      author:'Francis F',
      body:'This is article two'
    },
    {
    id:3,
      title:'Article Three',
      author:'Jam A',
      body:'This is article three'
    }  
];
  res.render('index', { title: 'Articles', articles : articles }); 
});
router.get('/articles/add', function(req, res, next) {
  res.render('add_article', { title: 'Add Article' }); 
}); 
module.exports = router;
